import os
from dataclasses import dataclass, field
from typing import Literal, Optional, Union

from .logging_utils import get_logger

logger = get_logger(__name__)


@dataclass
class BaseConfig:
    """One and only configuration."""

    # LLM specific attributes - read from environment
    llm_name: str = field(
        default="gpt-4o-mini", metadata={"help": "Class name indicating which LLM model to use."}
    )
    llm_base_url: str = field(
        default=None,
        metadata={"help": "Base URL for the LLM model, if none, means using OPENAI service."},
    )
    embedding_base_url: str = field(
        default=None,
        metadata={
            "help": "Base URL for an OpenAI compatible embedding model, if none, means using OPENAI service."
        },
    )
    azure_endpoint: str = field(
        default=None,
        metadata={
            "help": "Azure Endpoint URI for the LLM model, if none, uses OPENAI service directly."
        },
    )
    azure_embedding_endpoint: str = field(
        default=None,
        metadata={
            "help": "Azure Endpoint URI for the OpenAI embedding model, if none, uses OPENAI service directly."
        },
    )
    max_new_tokens: Union[None, int] = field(
        default=2048, metadata={"help": "Max new tokens to generate in each inference."}
    )
    num_gen_choices: int = field(
        default=1,
        metadata={"help": "How many chat completion choices to generate for each input message."},
    )
    seed: Union[None, int] = field(default=None, metadata={"help": "Random seed."})
    temperature: float = field(
        default=0, metadata={"help": "Temperature for sampling in each inference."}
    )
    response_format: Union[dict, None] = field(
        default_factory=lambda: {"type": "json_object"},
        metadata={"help": "Specifying the format that the model must output."},
    )

    # --- Настройки, добавленные upstream (fork/main) ---
    bedrock_mantle_auth: Literal["api_key", "aws_credentials"] = field(
        default="api_key",
        metadata={"help": "Authentication method for the Amazon Bedrock Mantle endpoint."},
    )
    bedrock_aws_profile: Optional[str] = field(
        default=None,
        metadata={"help": "AWS profile name used by the Bedrock Mantle backend."},
    )
    bedrock_region: Optional[str] = field(
        default=None,
        metadata={"help": "AWS region for the Bedrock Mantle backend."},
    )

    # Vector store backend
    vector_store_type: Literal["parquet", "qdrant", "chroma", "milvus"] = field(
        default="parquet",
        metadata={"help": "Which embedding store backend to use."},
    )

    # Qdrant-specific settings (only used when vector_store_type='qdrant')
    qdrant_url: Optional[str] = field(
        default=None,
        metadata={"help": "URL of a remote Qdrant server (e.g. 'http://localhost:6333')."},
    )
    qdrant_api_key: Optional[str] = field(
        default=None,
        metadata={"help": "API key for a remote Qdrant server."},
    )

    # ChromaDB-specific settings (only used when vector_store_type='chroma')
    chroma_host: Optional[str] = field(
        default=None,
        metadata={"help": "Hostname of a remote ChromaDB HTTP server."},
    )
    chroma_port: int = field(
        default=8000,
        metadata={"help": "Port of a remote ChromaDB HTTP server."},
    )

    # Milvus-specific settings (only used when vector_store_type='milvus')
    milvus_uri: Optional[str] = field(
        default=None,
        metadata={"help": "Milvus URI. If None, MILVUS_URI is used when set."},
    )
    milvus_token: Optional[str] = field(
        default=None,
        metadata={"help": "Milvus authentication token."},
    )
    milvus_db_name: Optional[str] = field(
        default=None,
        metadata={"help": "Milvus database name."},
    )
    milvus_consistency_level: Optional[Literal["Strong", "Session", "Bounded", "Eventually"]] = (
        field(
            default=None,
            metadata={"help": "Milvus consistency level."},
        )
    )

    ## LLM specific attributes -> Async hyperparameters
    max_retry_attempts: int = field(
        default=5,
        metadata={"help": "Max number of retry attempts for an asynchronous API calling."},
    )
    # Storage specific attributes
    force_openie_from_scratch: bool = field(
        default=False,
        metadata={
            "help": "If set to True, will ignore all existing openie files and rebuild them from scratch."
        },
    )

    # Storage specific attributes
    force_index_from_scratch: bool = field(
        default=False,
        metadata={
            "help": "If set to True, will ignore all existing storage files and graph data and will rebuild from scratch."
        },
    )
    rerank_dspy_file_path: str = field(
        default=None, metadata={"help": "Path to the rerank dspy file."}
    )
    passage_node_weight: float = field(
        default=0.05,
        metadata={"help": "Multiplicative factor that modified the passage node weights in PPR."},
    )
    save_openie: bool = field(
        default=True, metadata={"help": "If set to True, will save the OpenIE model to disk."}
    )

    # Preprocessing specific attributes
    text_preprocessor_class_name: str = field(
        default="TextPreprocessor",
        metadata={"help": "Name of the text-based preprocessor to use in preprocessing."},
    )
    preprocess_encoder_name: str = field(
        default="gpt-4o",
        metadata={
            "help": "Name of the encoder to use in preprocessing (currently implemented specifically for doc chunking)."
        },
    )
    preprocess_chunk_overlap_token_size: int = field(
        default=128, metadata={"help": "Number of overlap tokens between neighbouring chunks."}
    )
    preprocess_chunk_max_token_size: int = field(
        default=None,
        metadata={
            "help": "Max number of tokens each chunk can contain. If set to None, the whole doc will treated as a single chunk."
        },
    )
    preprocess_chunk_func: Literal["by_token", "by_word"] = field(default="by_token")

    # Information extraction specific attributes
    information_extraction_model_name: Literal["openie_openai_gpt",] = field(
        default="openie_openai_gpt",
        metadata={"help": "Class name indicating which information extraction model to use."},
    )
    openie_mode: Literal["offline", "online"] = field(
        default="online", metadata={"help": "Mode of the OpenIE model to use."}
    )
    skip_graph: bool = field(
        default=False,
        metadata={
            "help": "Whether to skip graph construction or not. Set it to be true when running vllm offline indexing for the first time."
        },
    )

    # Embedding specific attributes
    embedding_model_name: str = field(
        default="nvidia/NV-Embed-v2",
        metadata={"help": "Class name indicating which embedding model to use."},
    )
    embedding_batch_size: int = field(
        default=16, metadata={"help": "Batch size of calling embedding model."}
    )
    embedding_return_as_normalized: bool = field(
        default=True, metadata={"help": "Whether to normalize encoded embeddings not."}
    )
    embedding_max_seq_len: int = field(
        default=2048, metadata={"help": "Max sequence length for the embedding model."}
    )
    embedding_model_dtype: Literal["float16", "float32", "bfloat16", "auto"] = field(
        default="auto", metadata={"help": "Data type for local embedding model."}
    )

    # Graph construction specific attributes
    synonymy_edge_topk: int = field(
        default=2047, metadata={"help": "k for knn retrieval in buiding synonymy edges."}
    )
    synonymy_edge_query_batch_size: int = field(
        default=1000,
        metadata={
            "help": "Batch size for query embeddings for knn retrieval in buiding synonymy edges."
        },
    )
    synonymy_edge_key_batch_size: int = field(
        default=10000,
        metadata={
            "help": "Batch size for key embeddings for knn retrieval in buiding synonymy edges."
        },
    )
    synonymy_edge_sim_threshold: float = field(
        default=0.8, metadata={"help": "Similarity threshold to include candidate synonymy nodes."}
    )
    is_directed_graph: bool = field(
        default=False, metadata={"help": "Whether the graph is directed or not."}
    )

    # Retrieval specific attributes
    linking_top_k: int = field(
        default=5, metadata={"help": "The number of linked nodes at each retrieval step"}
    )
    retrieval_top_k: int = field(
        default=200, metadata={"help": "Retrieving k documents at each step"}
    )
    damping: float = field(default=0.5, metadata={"help": "Damping factor for ppr algorithm."})

    # QA specific attributes
    max_qa_steps: int = field(
        default=1,
        metadata={
            "help": "For answering a single question, the max steps that we use to interleave retrieval and reasoning."
        },
    )
    qa_top_k: int = field(
        default=5, metadata={"help": "Feeding top k documents to the QA model for reading."}
    )

    # Save dir (highest level directory)
    save_dir: str = field(
        default=None,
        metadata={
            "help": "Directory to save all related information. If it's given, will overwrite all default save_dir setups. If it's not given, then if we're not running specific datasets, default to `outputs`, otherwise, default to a dataset-customized output dir."
        },
    )

    # Dataset running specific attributes
    ## Dataset running specific attributes -> General
    dataset: Optional[
        Literal["hotpotqa", "hotpotqa_train", "musique", "2wikimultihopqa", "astrology"]
    ] = field(
        default="astrology",
        metadata={
            "help": "Dataset to use. If specified, it means we will run specific datasets. If not specified, it means we're running freely."
        },
    )
    ## Dataset running specific attributes -> Graph
    graph_type: Literal[
        "dpr_only",
        "entity",
        "passage_entity",
        "relation_aware_passage_entity",
        "passage_entity_relation",
        "facts_and_sim_passage_node_unidirectional",
    ] = field(
        default="facts_and_sim_passage_node_unidirectional",
        metadata={"help": "Type of graph to use in the experiment."},
    )
    corpus_len: Optional[int] = field(
        default=None, metadata={"help": "Length of the corpus to use."}
    )

    def __post_init__(self):
        env_llm_name = os.environ.get("LLM_NAME")
        if env_llm_name:
            self.llm_name = env_llm_name

        env_llm_base_url = os.environ.get("LLM_BASE_URL")
        if env_llm_base_url:
            self.llm_base_url = env_llm_base_url

        env_save_dir = os.environ.get("SAVE_DIR")
        if env_save_dir:
            self.save_dir = env_save_dir

        # Debug logging
        logger.info(f"BaseConfig: llm_name={self.llm_name}, llm_base_url={self.llm_base_url}")

        if self.save_dir is None:  # If save_dir not given
            if self.dataset is None:
                self.save_dir = "outputs"  # running freely
            else:
                self.save_dir = os.path.join(
                    "outputs", self.dataset
                )  # customize your dataset's output dir here
        logger.debug(f"Initializing the highest level of save_dir to be {self.save_dir}")


def build_working_dir(save_dir: str, llm_name: str, embedding_model_name: str) -> str:
    """Единое имя каталога индекса: `<llm>_<embedding>` с заменой '/' на '_' (S-22).

    Все компоненты (HippoRAG, StandardRAG, служебные скрипты) должны строить путь
    к каталогу индекса только через эту функцию: расхождение имён приводит к тому,
    что скрипты чистят или читают не тот каталог.
    """
    llm_label = str(llm_name).replace("/", "_")
    embedding_label = str(embedding_model_name).replace("/", "_")
    return os.path.join(save_dir, f"{llm_label}_{embedding_label}")
